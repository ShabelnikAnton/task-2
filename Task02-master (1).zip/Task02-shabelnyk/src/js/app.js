import '../scss/app.scss';

/* Your JS Code goes here */

/* Demo JS */
import './demo.js';
